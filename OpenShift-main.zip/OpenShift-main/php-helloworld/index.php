<?php
print "Hello, World! php version is " . PHP_VERSION . "\n";
print "Learning OpenShift is too much fun!!\n";
?>
